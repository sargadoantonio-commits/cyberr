<?php
// registration_login_ui/dashboard.php
// StyleSync - Dashboard (shown after successful login)

session_start();

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$username = htmlspecialchars($_SESSION['username']);
$role     = htmlspecialchars($_SESSION['role']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>StyleSync – Dashboard</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
  <div class="logo-wrap">
    <div class="logo-icon">S</div>
    <div class="logo-name">StyleSync</div>
    <div class="logo-sub">Men's Barbershop App</div>
  </div>

  <div class="card">
    <div class="alert success" style="display:block;">
      ✓ Logged in successfully!
    </div>
    <h2 class="card-title">Welcome, <?= $username ?>!</h2>
    <p class="card-sub">You are logged in as a <strong><?= $role ?></strong>.</p>
    <br>
    <a href="logout.php" class="btn" style="text-decoration:none; text-align:center; display:block;">
      Log Out
    </a>
  </div>
</div>
</body>
</html>
