<?php
// config.php - Database connection and environment loader
// Loads .env variables and returns a PDO database connection

// ── Load .env file ─────────────────────────────────────────────────────────
function loadEnv($filePath) {
    if (!file_exists($filePath)) {
        die('Error: .env file not found. Please create a .env file.');
    }
    $lines = file($filePath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        // Skip comment lines
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($key, $value) = explode('=', $line, 2);
            $key   = trim($key);
            $value = trim($value);
            // Store in $_ENV and putenv
            $_ENV[$key] = $value;
            putenv("$key=$value");
        }
    }
}

// Load the .env from the project root
loadEnv(__DIR__ . '/.env');

// ── Database Connection ────────────────────────────────────────────────────
function getDBConnection() {
    $host   = $_ENV['DB_HOST'] ?? 'localhost';
    $dbName = $_ENV['DB_NAME'] ?? 'cybersecurity_db';
    $user   = $_ENV['DB_USER'] ?? 'root';
    $pass   = $_ENV['DB_PASS'] ?? '';

    try {
        $pdo = new PDO(
            "mysql:host=$host;dbname=$dbName;charset=utf8mb4",
            $user,
            $pass,
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        die('Database connection failed: ' . $e->getMessage());
    }
}

// ── Get Pepper (from environment, NEVER from database) ────────────────────
function getPepper() {
    $pepper = $_ENV['PASSWORD_PEPPER'] ?? '';
    if (empty($pepper)) {
        die('Error: PASSWORD_PEPPER not set in .env file.');
    }
    return $pepper;
}
?>
