<?php
// registration_login_ui/login.php
// StyleSync - Login Module
// Handles both GET (show form) and POST (process login)

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../hashing_implementation/hash_helper.php';

session_start();

$error   = '';
$success = '';

// Show success message from registration redirect
if (isset($_SESSION['reg_success'])) {
    $success = $_SESSION['reg_success'];
    unset($_SESSION['reg_success']);
}

// ── Handle POST (login attempt) ───────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1. Retrieve inputs
    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password']      ?? '';

    // 2. Basic validation
    if (empty($email) || empty($password)) {
        $error = 'Please enter your email and password.';

    } else {
        // 3. Look up user by email
        $pdo  = getDBConnection();
        $stmt = $pdo->prepare(
            'SELECT id, username, email, role, password_hash, salt
             FROM users
             WHERE email = ?
             LIMIT 1'
        );
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user) {
            // User not found — use generic message to prevent user enumeration
            $error = 'Invalid username or password.';

        } else {
            // 4. Retrieve stored salt from DB
            //    Recompute hash: input_password + stored_salt + pepper
            //    Compare with stored hash (timing-safe via hash_equals)
            if (verifyPassword($password, $user['password_hash'], $user['salt'])) {

                // 5. Login successful — start session
                $_SESSION['user_id']  = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role']     = $user['role'];

                // Redirect to dashboard (or show success)
                header('Location: dashboard.php');
                exit();

            } else {
                // Wrong password — same generic message (prevents enumeration)
                $error = 'Invalid username or password.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>StyleSync – Sign In</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
  <div class="logo-wrap">
    <div class="logo-icon">S</div>
    <div class="logo-name">StyleSync</div>
    <div class="logo-sub">Men's Barbershop App</div>
  </div>

  <div class="card">
    <h2 class="card-title">Welcome back</h2>
    <p class="card-sub">Sign in to your account</p>

    <?php if ($success): ?>
      <div class="alert success">✓ <?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="alert error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php">

      <!-- Email -->
      <div class="field">
        <label for="email">Email</label>
        <div class="input-wrap">
          <input type="email" id="email" name="email"
                 placeholder="you@example.com"
                 value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
        </div>
      </div>

      <!-- Password -->
      <div class="field">
        <label for="password">Password</label>
        <div class="input-wrap">
          <input type="password" id="password" name="password"
                 placeholder="Your password" required>
          <button type="button" class="toggle-pw" onclick="togglePw('password',this)">Show</button>
        </div>
      </div>

      <div style="text-align:right; margin-bottom:1rem;">
        <a href="forgot_password.php" class="link-muted">Forgot password?</a>
      </div>

      <button type="submit" class="btn">Log In</button>

    </form>

    <div class="divider">or continue with</div>

    <div class="social-btns">
      <button class="social-btn">G &nbsp; Google</button>
      <button class="social-btn">f &nbsp; Facebook</button>
    </div>

    <p class="footer-links">
      No account? <a href="register.php">Register as Customer</a><br>
      Are you a barber? <a href="register.php">Register here</a>
    </p>

    <div class="security-note">
      🔒 SHA-256 + unique salt + pepper · Never stored in plain text
    </div>
  </div>
</div>

<script>
function togglePw(id, btn) {
  const inp = document.getElementById(id);
  inp.type = inp.type === 'password' ? 'text' : 'password';
  btn.textContent = inp.type === 'password' ? 'Show' : 'Hide';
}
</script>
</body>
</html>
