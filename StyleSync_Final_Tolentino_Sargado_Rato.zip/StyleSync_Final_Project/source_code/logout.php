<?php
// registration_login_ui/logout.php
session_start();
session_destroy();
header('Location: login.php');
exit();
?>
