<?php
// registration_login_ui/register.php
// StyleSync - Registration Module
// Handles both GET (show form) and POST (process registration)

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../hashing_implementation/hash_helper.php';

session_start();

$error   = '';
$success = '';

// ── Handle POST (form submission) ─────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1. Retrieve and sanitize inputs
    $fullname = trim($_POST['fullname'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email']    ?? '');
    $role     = $_POST['role'] === 'barber' ? 'barber' : 'customer';
    $password = $_POST['password']         ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    $agreed   = isset($_POST['agree']);

    // 2. Basic validation
    if (empty($fullname) || empty($username) || empty($email) || empty($password)) {
        $error = 'Please fill in all fields.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';

    } elseif (!$agreed) {
        $error = 'You must agree to the Terms of Service and Privacy Policy.';

    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';

    } else {
        // 3. Password strength check (server-side enforcement)
        $strength = checkPasswordStrength($password);
        if ($strength['score'] < 3) {
            $error = 'Password is too weak. It must meet at least 3 of the 5 requirements.';

        } else {
            // 4. Check username/email uniqueness in DB
            $pdo  = getDBConnection();
            $stmt = $pdo->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
            $stmt->execute([$username, $email]);

            if ($stmt->fetch()) {
                $error = 'Username or email already exists. Please choose another.';

            } else {
                // 5. Generate unique salt
                $salt = generateSalt();

                // 6. Hash: SHA-256( password + salt + pepper )
                $hash = hashPassword($password, $salt);

                // 7. Store in database — ONLY hash and salt, NEVER plaintext
                $insert = $pdo->prepare(
                    'INSERT INTO users (username, email, role, password_hash, salt)
                     VALUES (?, ?, ?, ?, ?)'
                );
                $insert->execute([$username, $email, $role, $hash, $salt]);

                // 8. Success — redirect to login with success message
                $_SESSION['reg_success'] = 'Account created successfully! Please log in with your username.';
                header('Location: login.php');
                exit();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>StyleSync – Create Account</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper">
  <div class="logo-wrap">
    <div class="logo-icon">S</div>
    <div class="logo-name">StyleSync</div>
    <div class="logo-sub">Men's Barbershop App</div>
  </div>

  <div class="card">
    <h2 class="card-title">Create Account</h2>

    <?php if ($error): ?>
      <div class="alert error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="register.php" id="regForm">

      <!-- Role selector -->
      <div class="role-tabs">
        <button type="button" class="role-tab active" onclick="setRole(this,'customer')">Customer</button>
        <button type="button" class="role-tab"        onclick="setRole(this,'barber')">Barber</button>
      </div>
      <input type="hidden" name="role" id="roleInput" value="customer">

      <!-- Full Name -->
      <div class="field">
        <label for="fullname">Full Name</label>
        <input type="text" id="fullname" name="fullname"
               placeholder="Your full name"
               value="<?= htmlspecialchars($_POST['fullname'] ?? '') ?>" required>
      </div>

      <!-- Username -->
      <div class="field">
        <label for="username">Username</label>
        <input type="text" id="username" name="username"
               placeholder="Choose a username"
               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
      </div>

      <!-- Email -->
      <div class="field">
        <label for="email">Email</label>
        <input type="email" id="email" name="email"
               placeholder="you@example.com"
               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
      </div>

      <!-- Password + Strength Meter -->
      <div class="field">
        <label for="password">Password</label>
        <div class="input-wrap">
          <input type="password" id="password" name="password"
                 placeholder="Min. 12 characters"
                 oninput="checkStrength(this.value)" required>
          <button type="button" class="toggle-pw" onclick="togglePw('password',this)">Show</button>
        </div>

        <!-- ── PASSWORD STRENGTH METER ── -->
        <div class="strength-wrap">
          <div class="strength-bar-bg">
            <div class="strength-bar-fill" id="strengthBar"></div>
          </div>
          <span class="strength-label" id="strengthLabel">Enter a password</span>

          <div class="strength-checks">
            <div class="check-item" id="chk-lower"><span class="dot"></span> Lowercase letter</div>
            <div class="check-item" id="chk-upper"><span class="dot"></span> Uppercase letter</div>
            <div class="check-item" id="chk-digit"><span class="dot"></span> Number</div>
            <div class="check-item" id="chk-symbol"><span class="dot"></span> Special character</div>
            <div class="check-item" id="chk-len"><span class="dot"></span> 12+ characters</div>
          </div>
        </div>
      </div>

      <!-- Confirm Password -->
      <div class="field">
        <label for="confirm_password">Confirm Password</label>
        <div class="input-wrap">
          <input type="password" id="confirm_password" name="confirm_password"
                 placeholder="Repeat your password" required>
          <button type="button" class="toggle-pw" onclick="togglePw('confirm_password',this)">Show</button>
        </div>
      </div>

      <!-- Terms agreement -->
      <div class="agree-row">
        <input type="checkbox" id="agree" name="agree">
        <label for="agree">I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></label>
      </div>

      <button type="submit" class="btn">Create Account</button>

      <p class="footer-links">Already have an account? <a href="login.php">Log In</a></p>

    </form>

    <div class="security-note">
      🔒 SHA-256 + unique salt + pepper · Never stored in plain text
    </div>
  </div>
</div>

<script>
// ── Role selector ──────────────────────────────────────────
function setRole(el, role) {
  document.querySelectorAll('.role-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('roleInput').value = role;
}

// ── Toggle password visibility ────────────────────────────
function togglePw(id, btn) {
  const inp = document.getElementById(id);
  inp.type = inp.type === 'password' ? 'text' : 'password';
  btn.textContent = inp.type === 'password' ? 'Show' : 'Hide';
}

// ── Password Strength Meter ───────────────────────────────
function checkStrength(pw) {
  const rules = {
    lower:  /[a-z]/.test(pw),
    upper:  /[A-Z]/.test(pw),
    digit:  /[0-9]/.test(pw),
    symbol: /[^a-zA-Z0-9]/.test(pw),
    len:    pw.length >= 12
  };

  // Update individual check items
  Object.keys(rules).forEach(k => {
    document.getElementById('chk-' + k).classList.toggle('pass', rules[k]);
  });

  const score = Object.values(rules).filter(Boolean).length;
  const bar   = document.getElementById('strengthBar');
  const lbl   = document.getElementById('strengthLabel');

  if (pw.length === 0) {
    bar.style.width = '0%';
    lbl.textContent = 'Enter a password';
    lbl.className = 'strength-label';
  } else if (score <= 2) {
    bar.style.width = '33%'; bar.style.background = '#f85149';
    lbl.textContent = '⚠ Weak';   lbl.className = 'strength-label weak';
  } else if (score <= 4) {
    bar.style.width = '66%'; bar.style.background = '#e3b341';
    lbl.textContent = '◐ Medium'; lbl.className = 'strength-label medium';
  } else {
    bar.style.width = '100%'; bar.style.background = '#3fb950';
    lbl.textContent = '✓ Strong'; lbl.className = 'strength-label strong';
  }
}

// ── Client-side validation before submit ──────────────────
document.getElementById('regForm').addEventListener('submit', function(e) {
  const pw  = document.getElementById('password').value;
  const cfm = document.getElementById('confirm_password').value;
  if (pw !== cfm) {
    e.preventDefault();
    alert('Passwords do not match.');
    return;
  }
  // Count strength score
  const score = [/[a-z]/,/[A-Z]/,/[0-9]/,/[^a-zA-Z0-9]/].filter(r=>r.test(pw)).length
                + (pw.length >= 12 ? 1 : 0);
  if (score < 3) {
    e.preventDefault();
    alert('Password is too weak. Please make it stronger.');
  }
});
</script>
</body>
</html>
