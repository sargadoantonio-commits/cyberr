<?php
// index.php - StyleSync Login Page
// Redirect to login
header('Location: login.php');
exit();
?>
