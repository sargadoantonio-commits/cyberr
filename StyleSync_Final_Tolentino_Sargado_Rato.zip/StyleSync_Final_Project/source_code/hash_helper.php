<?php
// hashing_implementation/hash_helper.php
// StyleSync - Password Hashing Implementation
// Algorithm: SHA-256 + unique salt + pepper (from .env)

require_once __DIR__ . '/../config.php';

// ============================================================
// FUNCTION: Generate a unique random salt
// ── Uses cryptographically secure random bytes (PHP 7+)
// ── bin2hex(random_bytes(16)) = 128 bits of entropy
// ── Result: 32-character hexadecimal string
// ============================================================
function generateSalt() {
    // random_bytes() uses the OS CSPRNG (e.g. /dev/urandom on Linux)
    return bin2hex(random_bytes(16));
}

// ============================================================
// FUNCTION: Hash a password using SHA-256 + salt + pepper
// ── Combines: password + salt + pepper → SHA-256 digest
// ── Returns: 64-character hexadecimal hash string
// ── The pepper is retrieved from the .env environment variable
//    (NEVER passed in as a parameter from user input)
// ============================================================
function hashPassword($plainPassword, $salt) {
    // Retrieve pepper from server environment (never from DB)
    $pepper = getPepper();

    // Combine: password + salt + pepper
    $combined = $plainPassword . $salt . $pepper;

    // Apply SHA-256 hash — one-way, irreversible
    return hash('sha256', $combined);
}

// ============================================================
// FUNCTION: Verify a login attempt
// ── Retrieves stored salt from the database
// ── Recomputes hash: input_password + stored_salt + pepper
// ── Compares with stored hash using hash_equals()
//    (timing-safe comparison to prevent timing attacks)
// ============================================================
function verifyPassword($inputPassword, $storedHash, $storedSalt) {
    // Recompute the hash with the same salt and pepper
    $attemptHash = hashPassword($inputPassword, $storedSalt);

    // Use hash_equals for timing-safe string comparison
    // This prevents timing attacks where an attacker measures
    // response time to guess correct hash characters
    return hash_equals($storedHash, $attemptHash);
}

// ============================================================
// FUNCTION: Check password strength
// ── Returns array of checks and overall score (0-5)
// ============================================================
function checkPasswordStrength($password) {
    $checks = [
        'lowercase' => (bool) preg_match('/[a-z]/', $password),
        'uppercase' => (bool) preg_match('/[A-Z]/', $password),
        'digit'     => (bool) preg_match('/[0-9]/', $password),
        'symbol'    => (bool) preg_match('/[^a-zA-Z0-9]/', $password),
        'length'    => strlen($password) >= 12,
    ];

    $score = array_sum($checks); // 0 to 5

    if ($score <= 2) {
        $rating = 'Weak';
    } elseif ($score <= 4) {
        $rating = 'Medium';
    } else {
        $rating = 'Strong';
    }

    return [
        'checks' => $checks,
        'score'  => $score,
        'rating' => $rating,
    ];
}
?>
