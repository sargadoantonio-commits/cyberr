-- ============================================================
-- StyleSync Database Schema
-- cybersecurity_db
-- ============================================================

-- Create the database
CREATE DATABASE IF NOT EXISTS cybersecurity_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE cybersecurity_db;

-- ── Users Table ───────────────────────────────────────────
-- NOTE: password_hash stores the SHA-256 hash ONLY
--       salt is stored here (unique per user)
--       pepper is NEVER stored here (lives in .env)
-- ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id            INT(11)      NOT NULL AUTO_INCREMENT,
    username      VARCHAR(50)  NOT NULL UNIQUE,
    email         VARCHAR(100) NOT NULL UNIQUE,
    role          ENUM('customer', 'barber') NOT NULL DEFAULT 'customer',
    password_hash VARCHAR(64)  NOT NULL,   -- SHA-256 = 64 hex chars
    salt          VARCHAR(32)  NOT NULL,   -- 16 random bytes = 32 hex chars
    created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
                                          ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Sample test user (password: Cyber@2026Secure) ─────────
-- This is for testing only. Remove before production.
-- INSERT INTO users (username, email, role, password_hash, salt)
-- VALUES ('testuser', 'test@example.com', 'customer', '<hash>', '<salt>');
